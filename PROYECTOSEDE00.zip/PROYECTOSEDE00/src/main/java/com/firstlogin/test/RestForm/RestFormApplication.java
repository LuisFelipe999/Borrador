package com.firstlogin.test.RestForm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestFormApplication.class, args);
	}

}
